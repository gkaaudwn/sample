public class ForDemo1{
	public static void main(String[] args){

		for(int a = 1; a<=10;a++){
			System.out.println("a�� ��:"+a);
		}
	}
}
