public class ForDemo2{
	public static void main(String[] args){
		
		for(int a =1;a<10;a++){
			System.out.println(2+"*"+a+"="+(2*a));
		}
	}
}
