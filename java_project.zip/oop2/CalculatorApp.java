public class CalculatorApp{
	public static void main(String[] args){

		Calculator c = new Calculator();
		int result = c.Plus(2,2);
		System.out.println(result);
	}
}
