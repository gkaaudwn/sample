public class CarApp{
	public static void main(String[]args){

		Car car = new Car();
		
	}
}
