public class App
{
	public static void main(String [] args){
	A a=new A();
	a.m();

	
	}
}
