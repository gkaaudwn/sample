public class Demo8{
	public static void main(String[] args){
	int a = 86.7;
	System.out.println(a);
	}
}
